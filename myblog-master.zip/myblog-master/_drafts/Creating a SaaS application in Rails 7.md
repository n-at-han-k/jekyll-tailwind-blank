1. Project Setup (bootstrap)
2. User login (devise)
3. User authorization (pundit)
4. Multi-tenancy (acts_as_tenant)
5. Stripe Subscriptions
6. Testing Stripe (Webhooks)
7. Styling (CSS)
