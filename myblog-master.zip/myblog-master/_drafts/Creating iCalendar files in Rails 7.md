
We use the `icalendar` gem available [here](https://github.com/icalendar/icalendar) 

Install to your project with this command:
```bash
bundle add icalendar
```

Your rails model will need the following:
- Start time
- End time

End time can be created using a duration.