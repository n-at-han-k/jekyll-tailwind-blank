
There’s a great cheat sheet here: https://gist.github.com/raghubetina/d5fc3df67ddbadcac271

Using:
- text fields
- Select fields
- Multiple select fields

