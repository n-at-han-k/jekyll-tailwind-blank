
Follow BetterSpecs to learn how to properly use RSpec [https://www.betterspecs.org](https://www.betterspecs.org/). That way you don’t have to think about what might be a good way to write a test. It’s already decided for you. It’s literally just a single page so easy to reference and read.

Also use RSpec documentation http://rspec.info/documentation/3.12/rspec-core/ 

## Pundit
https://www.thunderboltlabs.com/blog/2013/03/27/testing-pundit-policies-with-rspec/
https://til.codes/pundit-for-authorization-with-rspec-rails/