
TurboStreams are good for when you don’t want to persist things.
TurboFrames rely on data being persisted to work (as if changing page)