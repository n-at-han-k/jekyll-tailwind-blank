
When serialising models to json use this guidance:
https://stackoverflow.com/questions/9055786/specifying-attributes-of-a-rails-object-passed-into-a-json-object#9055825

To customise authentication views
`rails g doorkeeper:views`

Gist example integration for rails:
https://gist.github.com/endymion/5806493

Z Object DOcs:
https://github.com/zapier/zapier-platform/blob/main/packages/cli/README.md#z-object


Token Auth is required for testing in Zapier cli
https://blog.dennisokeeffe.com/blog/2022-03-16-part-10-devise-token-auth
https://devise-token-auth.gitbook.io/devise-token-auth/

Creating a custom environment in jest
https://www.typescriptsos.com/tools/how-to-create-jest-custom-environment-with-typescript/
https://archive.jestjs.io/docs/en/configuration#testenvironment-string
https://stackoverflow.com/questions/75047051/jest-class-extends-value-object-is-not-a-constructor-or-null


