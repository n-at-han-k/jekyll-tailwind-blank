
Add method to your model called `to_receipt` by doing this you can litterally get a receipt anywhere by doing nothing.